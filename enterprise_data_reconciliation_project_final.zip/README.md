# Enterprise Data Architecture & Reconciliation

## Project Objective
Build a Python/SQL data pipeline that extracts, cleans, reconciles, and visualizes enterprise financial transaction data from three messy systems.

## Input Systems
1. `enterprise_database.db` — historical user account records.
2. `server_logs.txt` — 100,000 raw transaction log lines.
3. `daily_exchange_rates.csv` — daily EUR/USD rates with missing dates.

## Pipeline
**SQL latest-user extraction → Regex parsing → Exchange-rate forward fill → Reconciliation joins → USD revenue → Aggregation → Visualization**

## Final Results
- Raw server logs: **100,000**
- ERROR logs removed: **5,098**
- Valid transactions extracted: **94,902**
- Historical user rows in database: **47,464**
- Unique users in database: **25,000**
- Latest Active users: **14,183**
- Final reconciled transactions: **53,899**
- Missing exchange-rate dates before fill: **104**
- Missing exchange-rate values after fill: **0**
- Total reconciled USD revenue: **$148,274,622.91**

## Technical Skills Demonstrated
- SQLite / SQL Window Functions
- Python
- Pandas vectorized string processing
- Regular Expressions
- Data cleaning and validation
- Temporal joins and forward filling
- Data reconciliation
- Aggregation and business analysis
- Matplotlib visualization

## Key Data-Quality Findings
- The server log contains both valid `INFO` transactions and corrupted/failed `ERROR` records.
- Transaction fields are embedded in unstructured log text and must be extracted with Regex.
- Customer records are historical; `ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY updated_at DESC)` is used to identify each user's latest status.
- The supplied exchange-rate CSV contains **104 missing dates**. The actual supplied data has 52 missing Fridays and 52 missing Saturdays; the pipeline follows the dataset and applies chronological forward-fill.
- The final reconciliation retains only transactions belonging to customers whose latest database status is `Active`.

## Business Outputs
- `monthly_revenue.csv` — monthly reconciled USD revenue
- `top5_customers.csv` — five highest-value customers
- `revenue_by_month.png` — revenue trend visualization
- `top5_customers.png` — top customer visualization

## How to Run
Place the three input files in the same directory as `enterprise_reconciliation.ipynb`, install the packages in `requirements.txt`, and run the notebook from top to bottom.

## Submission Files
- `enterprise_reconciliation.ipynb`
- `active_users.sql`
- `README.md`
- `requirements.txt`
- `extracted_transactions.csv`
- `final_reconciled_transactions.csv`
- `monthly_revenue.csv`
- `top5_customers.csv`
- `revenue_by_month.png`
- `top5_customers.png`
- Original input files (`enterprise_database.db`, `server_logs.txt`, `daily_exchange_rates.csv`)

## Business Outcome
The completed pipeline produces an audit-ready transaction table containing valid transactions, active customers, applicable exchange rates, and calculated USD revenue. It also provides monthly revenue and customer-concentration summaries for management review.
