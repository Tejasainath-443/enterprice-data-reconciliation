-- Enterprise Data Reconciliation
-- Select the latest historical record for each user and keep only Active users.

WITH ranked_users AS (
    SELECT
        user_id,
        name,
        status,
        updated_at,
        ROW_NUMBER() OVER (
            PARTITION BY user_id
            ORDER BY updated_at DESC
        ) AS rn
    FROM users
)
SELECT
    user_id,
    name,
    status,
    updated_at
FROM ranked_users
WHERE rn = 1
  AND status = 'Active';
